Error: <?php echo $msg; ?>

