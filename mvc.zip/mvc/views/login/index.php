<h1>Login</h1>
<form action="login/run" method="post">
	<label>Login</label><input type="text" name="login"/>
	</br>
	<label>Password</label><input type="password" name="password"/>
	</br>
        <a href="login/passwordForgoten">Password forgoten?</a>
        </br></br>
	<label></label><input type="submit" />
</form>
