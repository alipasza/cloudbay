<?php 

define('URL','http://localhost/mvc/');

?>