<?php

class Dashboard extends Controller {
	
    function __construct() {

        parent:: __construct();
        Session::init();
        $loggedIn = Session::get('loggedIn');
        if ($loggedIn == false) {
            Session::destroy();
            header('location: ../login');
            exit;
        }
        
        $this->view->js = array('dashboard/js/default.js');
    }
	
    public function index() {
        $this->view->render('dashboard/index');
    }
        
    public function logout() {
        Session::destroy();
        header('location: ../login');
        exit;
    }
	
    function xhrInsert() {
        //echo '<br>bez szalu w Dashboard.xhrInsert()';
        $this->model->xhrInsert();
    }
    
    function xhrGetListings() {
        //echo '<br>bez szalu w Dashboard.xhrGetListings()';
        $d1=$this->model->xhrGetListings();
        print_r($d1);
    }
    
    function xhrDeleteListing() {
        $this->model->xhrDeleteListing();   
    }
    
    function user() {
        $this->view->render('user/index');
    }
}
?>