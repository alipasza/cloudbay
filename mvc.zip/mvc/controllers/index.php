<?php

class Index extends Controller {
	
	function __construct() {
                //echo '<br>uruchomiono konstruktor kontrolera Index(controlls\index.php)';
		parent:: __construct();
	}
	
	public function index() {
            //echo '<br>Metoda Index kontrolera Index wywoluje metode View->render z klasy bazowej View z parametem="index/index"';
            $this->view->render('index/index');
	}
	
	public function details() {
		$this->view->render('index/index');
	}
}


?>