<?php 

class Error extends Controller {
	
	function __construct($arg = '') {
            
            parent:: __construct();
	}
        
	public function showError($arg) {
				
	$this->view->render('error/index', $arg);
	}
	
	public function index() {
				
            $this->view->render('error/index', 'This page doesnt exists');
	}
}
?>