<?php

class Login extends Controller {
	
	function __construct() {
		parent:: __construct();
		//echo '<br>Controller klasy Login(controllers\login.php):konstruktor';
                echo URL;
	}
	
	public function index() {
		$this->view->render('login/index');
	}

	public function run() {
            
            $res=$this->model->run($_POST['login'], $_POST['password'], $role);
            
            if ( $res = true) {
                Session::init();
                Session::set('role',$role);
                Session::set('loggedIn', true);
                header('location: ' . URL . 'dashboard');
                //require 'controllers\dashboard.php';
                //$dashboard = new Dashboard();
                //$dashboard->view->render('dashboard/index');
            }
            else {
                Session::destroy();
                //$this->view->render('login/index'); 
                header('location: ' . URL . 'login');
            }
	}
}


?>