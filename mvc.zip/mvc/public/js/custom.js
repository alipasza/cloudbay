$(document).ready(function() {
	/*
	alert("Jestem w Custom");*/
});