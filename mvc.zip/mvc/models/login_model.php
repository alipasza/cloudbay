<?php 

class Login_Model extends Model {
	
	function __construct() {
            parent:: __construct();
            //echo '<br>Login_Model(models\login_model.php):konstruktor';
        }
	
        public function run($login, $password, &$role) {
            
            $sth = $this->db->prepare("SELECT id, role FROM users WHERE login = :login AND password = MD5(:password)");
            $sth->execute(array(
                ':login' => $login,
                ':password' => $password
            ));  
            
            $data = $sth->fetch();
            $role = $data['role'];
            $count = $sth->rowCount();
            if ( $count > 0 ) {   
                return true;
            }
            else {
                return false;
            }
            return false;
        }
	
}
?>