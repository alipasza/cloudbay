<?php 

class Help_Model extends Model {
	
	function __construct() {
		parent:: __construct();
		//echo '<br>This is Help_model';
	}
	public function blah() {
		return 10+10;
	}
}

?>