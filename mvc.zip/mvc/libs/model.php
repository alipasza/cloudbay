<?php

class Model {
	
	function __construct() {
		$this->db = new Database();
		//echo '<br>This is base Model';
	}
}

?>