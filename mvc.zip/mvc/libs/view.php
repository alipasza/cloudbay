<?php

class View {
	
	function __construct() {
            //echo '<br>uruchomiono konstruktor klasy bazowej View (libs\view.php)';
	}
	public function Pokaz() {
		//echo 'Pokaz sie';
	}
	public function render($name, $par1='') {
		//echo '<br>Funkcja render klasy bazowej View ładuje views-a:' . $name.'.php';
		$msg=$par1;
		if (strpos($name,'.php') > 0) {
			$name=substr($name, 0,strpos($name,'.php'));
		}
		require '/views/header.php';
		require '/views/' . $name . '.php';
		require '/views/footer.php';
	}
}

?>