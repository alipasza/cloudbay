<?php 

class bootstrap {
	
	function __construct() {
		$url = isset($_GET['url']) ? $_GET['url'] : null;
		$url = rtrim($url,'/');
		$url = explode('/',$url);
		//echo '<br>Obiekt Bootstrap: parsuje url:';
		//print_r($url);

		if (strpos($url[0],'.php') > 0) {
				$url[0]=substr($url[0], 0,strpos($url[0],'.php'));
		}
		
		if (empty($url[0])) {
			require 'controllers/index.php';
                        //echo '<br>Obiekt Bootstrap:powoluje obiekt kontrolera domyślnego:  Index (controlls\index,php)';
			$controller = new Index();
			//echo '<br>Bootstrap:kieruje sterowanie do: metody Index kontrolera Index (controlls\index.php metoda Index()';
			$controller->index();
			return false;
		}

		$file = 'controllers/' . $url[0] . '.php';
		if (file_exists($file)) {
			require $file;
		}
		else {
			require 'controllers/error.php';
			$controller = new Error('The file:' . $file . ' does not exists.');
			return false;
		}
		//echo '<br>Obiekt Bootstrap: powoluje obiekt kontrolera:  ' . $url[0].'(controlls\\'.$url[0].',php)';
		$controller = new $url[0];
		//echo '<br>Bootstrap: próbuje załadować jeżeli istnieje model dla kontrolera "'.$url[0].'": wywoluje metode loadModel z kontrolera bazowego Controller poprzez obiekt kontrolera  ' . $url[0].'()';
		$controller->loadModel($url[0]);
		
		//calling methods 
		if (isset($url[2])) {
			if (method_exists($controller,$url[1])) {
				//echo '<br>Bootstrap:kieruje sterowanie do:' . 'controllers/' . $url[0] . '.php; do funkcji ' . $url[1] . ' z parametrem ' . $url[2];
				$controller ->{$url[1]}($url[2]);
			}
			else {
				require 'controllers/error.php';
				$error = new Error();
				$error->showError('There is no method:"' . $url[1] . '" in class:"' . $url[0] . '"');
			}
		}
		else {
			if (isset($url[1])) {
				if (method_exists($controller,$url[1])) {
					//echo '<br>Bootstrap:kieruje sterowanie do:' . 'controllers/' . $url[0] . '.php; do funkcji ' . $url[1];
					$controller ->{$url[1]}();
				}
				else {
					require 'controllers/error.php';
					$error = new Error();
					$error->showError('There is no method:"' . $url[1] . '" in class:"' . $url[0] . '"');
				}
			}
			else {
					//echo '<br>Bootstrap:kieruje sterowanie do:' . 'controllers/' . $url[0] . '.php; funkcja index()';
					$controller->index();
			}
		}
	}
}

?>
